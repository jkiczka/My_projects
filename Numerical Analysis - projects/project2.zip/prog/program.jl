using DataFrames, CSV, Plots, QuadGK, Polynomials

function CompositeTrapezoid(f,n,a,b)
h=(b-a)/n
xs=LinRange(a,b,n+1)
ys=f.(xs)
ys[1]*=0.5
ys[n+1]*=0.5
return Float64(h*sum(ys))
end

function CompositeSimpson(f,n,a,b)
h=(b-a)/n
xs=LinRange(a,b,n+1)
ys=f.(xs)
ys[2:2:n]*=4.0
ys[3:2:n-1]*=2.0
return Float64(h/3*sum(ys))
end

function Test(f,a,b,n)
T=Float64[]
S=Float64[]
T2=Float64[]
S2=Float64[]

for i in 2:10:n
	push!(T,CompositeTrapezoid(f,i,a,b))
	push!(S,CompositeSimpson(f,i,a,b))
end

wynik=Float64(quadgk(f,a,b)[1])
println(wynik)
Te=Float64[]
Se=Float64[]

for i in 1:length(T)
	push!(Te, abs(wynik-T[i])/abs(wynik))
	push!(Se, abs(wynik-S[i])/abs(wynik))
end

df=DataFrame(n=1:10:n, Trapezoid=T, Error_T=Te,Simpson=S, Error_S=Se)
    
df[!, :Error_T] = round.(df[:,:Error_T,], digits=12)
df[!, :Error_S] = round.(df[:,:Error_S,], digits=12)

println(df)
x = 2:10:n; y1=[Te, Se]
CSV.write(string("d01.csv"),df)
    
plot(x,y1, xscale=:log10, label=["Trapezoid" "Simpson"], markersize=1, xlabel="Liczba węzłów", ylabel="Wartość błędu",titlefontsize=10,title="Zależność między liczbą węzłów a wartością błędu \n dla metody Simpsona i metody trapezów", marker=true;)

end

f1(x)=(x-1)^2*(x-2)*(x-3)^3*(x-4)

plot(f1, xlims=(1,4), label="f1(x)")

savefig("f1_plot.png")

using Polynomials

p=fromroots([1,1,2,3,3,3,4])
function max_deriv(p,a,b,k)
d=derivative(p,k)
X=roots(d)
#X=filter(x->(x.im==0),X)
X=Float64.(X)
X=filter(x->(x>=a && x<=b),X)
X=p.(X)
push!(X,d(a))
push!(X,d(b))
X=abs.(X)
return findmax(X)[1]
end


md2=max_deriv(p,1,4,2)
md4=max_deriv(p,1,4,4)
#Maksymalny błąd dla 291 węzłów:
println("Trapezoid:", md2*2^3/(12*291^2), "\nSimpson:", md4*2^5/(180*291^4))

Test(f1,1,4,300)

savefig("f_1.png")

f2(x)=(x-1)*(x-3)*(x+1)*(x+5)^2*(x-9)*(x+7)*(x-7)*(x+5.5)

p=fromroots([1,3,-1,-5,-5,9,-7,7,-5.5])
md2=max_deriv(p,-5,5,2)
md4=max_deriv(p,-5,5,4)
#Maksymalny błąd dla 291 węzłów:
println("Trapezoid:", md2*10^3/(12*191^2), "\nSimpson:", md4*10^5/(180*191^4))

plot(f2, xlims=(-5,5), label="f2(x)")

Test(f2,-5,5,200)

f3(x)=x^100+3x^50+67x^33-9x^20-17x^15+18x^18-9x+13
Test(f3,-10,10,300)

savefig("f3.png")

g1(x)=1/(1+25x^2)

Test(g1,-1,1,100)

savefig("runge1.png")

Test(g1,-400,100,1000)

savefig("runge2.png")

g2(x)=(-5280+6208*x-778*x^2-159*x^3+8*x^4+x^5)/(x^2+1)

plot(g2, xlims=(-10,10), label="g2(x)")


savefig("g2plot.png")

plot(g2, xlims=(-100,100), label="g2(x)")


savefig("g2plot2.png")

Test(g2,-10,10,200)

Test(g2,-1000,1000,200)

savefig("f_1.png")

g3(x)=20x/(x^2+2)

plot(g3, label="g3(x)")

Test(g2,-5,5,200)

h1(x)=((sin(x))^10+13sin(x)cos(x)-(cos(x))^3)/((cos(x))^7+3)

plot(h1, label="h1(x)")

savefig("h1.png")

Test(h1,-10,10,200)

h2(x)=((sin(x))^9-(sin(x))^2cos(x)+(cos(x))^5)/((cos(x))^6+(sin(x))^7)

plot(h2, xlims=(0,2.9), label="h2(x)")

savefig("h2.png")

Test(h2,0,2.9,200)

h3(x)=((sin(x))^10+127*cos(x)^3)/(10+sin(x))


plot(h3,label="h3(x)")

savefig("h3.png")

Test(h3,-4,4,200)

function prec_t(f,a,b,p)
n=2
w=CompositeTrapezoid(f,n,a,b)
wynik=Float64(quadgk(f,a,b)[1])
while (abs((wynik-w)/wynik)>p)
    n=n+10
    w=CompositeTrapezoid(f,n,a,b)
    end
end



function prec_s(f,a,b,p)
n=2
w=CompositeSimpson(f,n,a,b)
wynik=Float64(quadgk(f,a,b)[1])
while (abs((wynik-w)/wynik)>p)
    n=n+10
    w=CompositeSimpson(f,n,a,b)
    end
end

a=@time prec_t(f1,1,2,10^(-10))
b=@time prec_s(f1,1,2,10^(-10))
println(a/b)

@time prec_t(f2,1,2,10^(-10))
@time prec_s(f2,1,2,10^(-10))



@time prec_t(g1,1,2,10^(-10))
@time prec_s(g1,1,2,10^(-10))

@time prec_t(g2,1,2,10^(-10))
@time prec_s(g2,1,2,10^(-10))

@time prec_t(g3,1,2,10^(-10))
@time prec_s(g3,1,2,10^(-10))

@time prec_t(h1,1,2,10^(-10))
@time prec_s(h1,1,2,10^(-10))

@time prec_t(h2,1,2,10^(-10))
@time prec_s(h2,1,2,10^(-10))

@time prec_t(h3,1,2,10^(-10))
@time prec_s(h3,1,2,10^(-10))


