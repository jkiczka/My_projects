using DataFrames
using CSV
using Plots

function integral(n)
  V=(typeof(n))[]
  prev=typeof(n)(log(11/10))
  for i in 1:n
    next=(1/i)-(10*prev)
    push!(V, next)
    prev=next
  end
  return V
end

function integral2(n)
  V=[typeof(n)(0.0)]
  prev=0
  for i in n:-1:1
    next=((1/(i+1))-prev)/10
    push!(V, next)
    prev=next
  end
  return reverse(V)
end

w1=(integral(Float32(21.0)))
w2=(integral2(Float32(20.0)))
df=DataFrame(Iteracja=1:21, I=w1, II=w2)
CSV.write("tab_1.csv",df)

x = 1:21; y1=[w1, w2]
plot(x,y1,legend=:bottomleft, label=["I" "II"], ylims=(-1000,1000), markersize=1, marker=true)
savefig("fig1.png")

w1=(integral(Float64(21.0)))
w2=(integral2(Float64(20.0)))
df2=DataFrame(Iteracja=1:21, I=w1, II=w2)
CSV.write("tab_2.csv",df2)

x = 1:21; y1=[w1, w2]
plot(x,y1,legend=:bottomleft, label=["I" "II"], ylims=(-1000,1000), markersize=1, marker=true)
savefig("fig2.png")